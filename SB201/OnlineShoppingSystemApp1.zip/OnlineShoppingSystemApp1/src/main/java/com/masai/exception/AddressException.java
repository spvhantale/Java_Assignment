package com.masai.exception;

public class AddressException extends Exception {
	
	
	
	
	public AddressException() {
		// TODO Auto-generated constructor stub
	}
	

	public AddressException(String message) {
		super(message);
	}
	
	

}
