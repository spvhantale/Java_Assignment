package com.masai.exception;

public class CartException extends Exception {
	
	public CartException() {
		// TODO Auto-generated constructor stub
	}
	
	public CartException(String message) {
		super(message);
	}
	
	

}
