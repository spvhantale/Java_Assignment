package com.masai.dto;





import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	private Integer productId;
	
	private String productName;
	
	private Double price;
	
	private String color;
	
	private String dimension;
	
	private String manufacturer;
	
	private Integer quantity;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductDTO other = (ProductDTO) obj;
		return Objects.equals(color, other.color) && Objects.equals(dimension, other.dimension)
				&& Objects.equals(manufacturer, other.manufacturer) && Objects.equals(price, other.price)
				&& Objects.equals(productName, other.productName) && Objects.equals(quantity, other.quantity);
	}

	@Override
	public int hashCode() {
		return Objects.hash(color, dimension, manufacturer, price, productName, quantity);
	}


	
}
