package com.masai.exception;

public class OrderException extends Exception {
	
	public OrderException() {
		// TODO Auto-generated constructor stub
	}
	
	public OrderException(String message) {
		super(message);
	}

}
